"""
core/pipeline.py
Orchestrates detection → recognition → tracking → logging per frame.

Duplicate-prevention design
────────────────────────────
1.  _globally_seen_faces  : set of face_ids ever matched in this session.
    A face_id in this set will NEVER get a second unique-visitor increment,
    even if it exits and re-enters many times.

2.  _active_face_to_track : face_id → current track_id.
    Ensures only ONE track at a time owns a face_id. If a second detection
    matches the same face_id, the old track is silently reassigned rather
    than spawning a new entry.

3.  _track_to_face        : track_id → face_id.  (reverse of the above)

4.  _entry_active         : face_id → bool.
    True only while the person is currently in frame. An exit clears it,
    allowing a re-entry event to fire if the same person walks in again —
    but the visitor count is NOT incremented again (guarded by
    _globally_seen_faces).

5.  Embedding stabilisation (multi-sample average):
    Before registering a new face we collect EMBEDDING_SAMPLES crops over
    the next few detection cycles and average them. This dramatically reduces
    noise-triggered false new-registrations.

6.  config.json `max_distance` is now interpreted in PIXEL units (default
    120 px), not 0.5 (which is sub-pixel and breaks the tracker entirely).
"""

import logging
import uuid
from collections import defaultdict
from datetime import datetime
from typing import Dict, Optional, Set

import cv2
import numpy as np

from core.detector import FaceDetector
from core.recognizer import FaceRecognizer
from core.tracker import build_tracker, TrackState
from database.mongo_manager import MongoManager
from logging_system.event_logger import EventLogger

logger = logging.getLogger(__name__)

# How many embedding samples to average before deciding "new face"
EMBEDDING_SAMPLES = 5


class FaceTrackerPipeline:
    """
    Top-level controller that wires together every subsystem:
    Detector → Tracker → Recognizer → DB → Logger
    """

    def __init__(self, config: dict):
        self.config = config
        det_cfg = config["detection"]
        rec_cfg = config["recognition"]
        trk_cfg = config["tracking"]
        db_cfg  = config["database"]
        log_cfg = config["logging"]

        # ── subsystems ──────────────────────────────────────────────────
        self.detector = FaceDetector(
            model_path=det_cfg["yolo_model"],
            conf_thresh=det_cfg["confidence_threshold"],
            iou_thresh=det_cfg["iou_threshold"],
        )
        self.recognizer = FaceRecognizer(
            model_name=rec_cfg["model_name"],
            embedding_threshold=rec_cfg["embedding_threshold"],
            min_face_size=rec_cfg["min_face_size"],
        )

        # max_distance must be in PIXELS (e.g. 120).  Guard against the
        # common mistake of passing a cosine-style float like 0.5.
        raw_dist = float(trk_cfg["max_distance"])
        pixel_dist = raw_dist if raw_dist >= 1.0 else 120.0
        if raw_dist < 1.0:
            logger.warning(
                "max_distance=%.2f looks like a cosine value, not pixels. "
                "Overriding to 120 px for the centroid tracker.", raw_dist
            )

        self.tracker = build_tracker(
            tracker_type=trk_cfg["tracker_type"],
            max_disappeared=trk_cfg["max_disappeared"],
            max_distance=pixel_dist,
        )
        self.db = MongoManager(
            uri=db_cfg["uri"],
            db_name=db_cfg["name"],
            collections=db_cfg["collections"],
        )
        self.event_logger = EventLogger(
            log_file=log_cfg["log_file"],
            image_base_dir=log_cfg["image_base_dir"],
        )

        # ── runtime state ────────────────────────────────────────────────
        self.frame_skip: int = det_cfg["frame_skip"]
        self._frame_count: int = 0

        # track_id  →  face_id  (what recognised identity owns this track)
        self._track_to_face: Dict[int, str] = {}

        # face_id  →  track_id  (reverse; prevents two tracks → same face)
        self._active_face_to_track: Dict[str, int] = {}

        # face_ids that are CURRENTLY inside the frame (cleared on exit)
        self._entry_active: Set[str] = set()

        # face_ids seen at least once this session → NEVER double-count
        self._globally_seen_faces: Set[str] = set()

        # Embedding accumulator for stabilisation before registering
        # track_id → list of embedding vectors collected so far
        self._pending_embeddings: Dict[int, list] = defaultdict(list)

        # In-memory cache: list of {"face_id": ..., "embedding": [...]}
        self._face_cache: list = []
        self._refresh_face_cache()

        # Pre-populate globally_seen from DB (handles restarts mid-session)
        for f in self._face_cache:
            self._globally_seen_faces.add(f["face_id"])

        logger.info("FaceTrackerPipeline initialised. %d known faces loaded.",
                    len(self._face_cache))

    # ── Cache ────────────────────────────────────────────────────────────

    def _refresh_face_cache(self):
        self._face_cache = self.db.get_all_faces()
        logger.debug("Face cache refreshed: %d known faces.", len(self._face_cache))

    # ── Per-frame processing ─────────────────────────────────────────────

    def process_frame(self, frame: np.ndarray) -> np.ndarray:
        """Process a single BGR frame and return the annotated version."""
        self._frame_count += 1
        run_detection = (self._frame_count % (self.frame_skip + 1) == 0)

        # ── Detection ──
        detections = self.detector.detect(frame) if run_detection else []

        # ── Tracking ──
        active_tracks = self.tracker.update(detections)

        # ── Recognition & Registration ──
        if run_detection:
            for track in active_tracks:
                self._process_track(frame, track)

        # ── Handle exits ──
        lost = self.tracker.remove_lost_tracks()
        for track in lost:
            self._handle_exit(frame, track)

        # ── Annotate ──
        return self._draw_annotations(frame.copy(), active_tracks)

    # ── Track processing ─────────────────────────────────────────────────

    def _process_track(self, frame: np.ndarray, track: TrackState):
        """
        For each active track on a detection frame:
        - If already resolved to a face_id → nothing to do.
        - Otherwise accumulate embeddings; once we have enough, resolve.
        """
        if track.track_id in self._track_to_face:
            # Already identified – just keep face_id in sync on the object
            track.face_id = self._track_to_face[track.track_id]
            return

        crop = self.detector.crop_face(frame, track.bbox)
        embedding = self.recognizer.get_embedding(crop)
        if embedding is None:
            return

        # Accumulate embeddings for stability
        self._pending_embeddings[track.track_id].append(embedding)

        samples = self._pending_embeddings[track.track_id]
        if len(samples) < EMBEDDING_SAMPLES:
            # Not enough samples yet – wait for more frames
            return

        # Average the accumulated embeddings and normalise
        avg_emb = np.mean(np.stack(samples), axis=0)
        norm = np.linalg.norm(avg_emb)
        avg_emb = avg_emb / norm if norm > 0 else avg_emb

        # Clear accumulator
        del self._pending_embeddings[track.track_id]

        # Match against known faces
        face_id, similarity = self.recognizer.find_best_match(
            avg_emb, self._face_cache
        )

        if face_id is not None:
            # ── Known face recognised ──────────────────────────────────
            # Check if this face_id is already owned by a DIFFERENT active track.
            # That would be a false match (two people look similar). Keep old track.
            existing_track = self._active_face_to_track.get(face_id)
            if existing_track is not None and existing_track != track.track_id:
                logger.debug(
                    "face_id %s already active on track %d – ignoring match for track %d",
                    face_id, existing_track, track.track_id,
                )
                return

            self.db.update_face_last_seen(face_id)
            logger.info("Recognised face %s (sim=%.3f) on track %d",
                        face_id, similarity, track.track_id)
        else:
            # ── New face – register ────────────────────────────────────
            face_id = self._generate_face_id()
            image_path = self.event_logger.save_face_image(crop, face_id, "registration")
            self.db.register_face(
                face_id=face_id,
                embedding=avg_emb.tolist(),
                image_path=image_path,
                metadata={"track_id": track.track_id},
            )
            # Add to in-memory cache immediately so subsequent tracks in
            # the SAME frame don't re-register this person.
            self._face_cache.append(
                {"face_id": face_id, "embedding": avg_emb.tolist()}
            )
            self.event_logger.log(
                f"REGISTER | face_id={face_id} | track_id={track.track_id} | "
                f"sim_at_reg=None (new)"
            )
            logger.info("New face registered: %s (track %d)", face_id, track.track_id)

        # ── Bind track ↔ face_id ──────────────────────────────────────
        self._track_to_face[track.track_id] = face_id
        self._active_face_to_track[face_id] = track.track_id
        track.face_id = face_id
        track.embedding = avg_emb

        # ── Entry event ───────────────────────────────────────────────
        # Fire if this face is not currently "inside" (handles re-entries).
        # Unique visitor increment is guarded separately by _globally_seen_faces.
        if face_id not in self._entry_active:
            self._fire_entry_event(frame, track, face_id)
            self._entry_active.add(face_id)

    # ── Exit handling ────────────────────────────────────────────────────

    def _handle_exit(self, frame: np.ndarray, track: TrackState):
        """Called when a track disappears beyond max_disappeared."""
        # Purge pending accumulator (track died before we had enough samples)
        self._pending_embeddings.pop(track.track_id, None)

        face_id = self._track_to_face.pop(track.track_id, None)
        if face_id is None:
            return

        # Release the face → track binding
        if self._active_face_to_track.get(face_id) == track.track_id:
            del self._active_face_to_track[face_id]

        if face_id in self._entry_active:
            self._fire_exit_event(frame, track, face_id)
            self._entry_active.discard(face_id)
            # NOTE: do NOT remove from _globally_seen_faces here.
            # That set is permanent for the whole session.

    # ── Events ───────────────────────────────────────────────────────────

    def _fire_entry_event(self, frame: np.ndarray, track: TrackState,
                          face_id: str):
        ts = datetime.utcnow()
        crop = self.detector.crop_face(frame, track.bbox)
        image_path = self.event_logger.save_face_image(crop, face_id, "entry")
        self.db.log_event(face_id, "entry", image_path, timestamp=ts)

        # Only increment unique visitor counter the VERY FIRST TIME ever seen
        is_new_unique = face_id not in self._globally_seen_faces
        if is_new_unique:
            self._globally_seen_faces.add(face_id)
            self.db.increment_unique_visitor()
            logger.info("NEW unique visitor: %s", face_id)

        self.event_logger.log(
            f"ENTRY | face_id={face_id} | track_id={track.track_id} | "
            f"new_unique={is_new_unique} | ts={ts.isoformat()}"
        )
        logger.info("ENTRY event – face=%s new_unique=%s", face_id, is_new_unique)

    def _fire_exit_event(self, frame: np.ndarray, track: TrackState,
                         face_id: str):
        ts = datetime.utcnow()
        crop = self.detector.crop_face(frame, track.bbox)
        image_path = self.event_logger.save_face_image(crop, face_id, "exit")
        self.db.log_event(face_id, "exit", image_path, timestamp=ts)
        self.event_logger.log(
            f"EXIT | face_id={face_id} | track_id={track.track_id} | ts={ts.isoformat()}"
        )
        logger.info("EXIT event – face=%s", face_id)

    # ── Annotation ───────────────────────────────────────────────────────

    def _draw_annotations(self, frame: np.ndarray,
                           tracks: list) -> np.ndarray:
        for track in tracks:
            x1, y1, x2, y2, _ = track.bbox
            face_id = self._track_to_face.get(track.track_id)

            # Colour coding: green = identified, yellow = pending ID
            colour = (0, 255, 0) if face_id else (0, 220, 255)
            short_id = face_id[-8:] if face_id else "pending…"
            label = f"{short_id} [T{track.track_id}]"

            cv2.rectangle(frame, (x1, y1), (x2, y2), colour, 2)
            # Background pill for legibility
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 1)
            cv2.rectangle(frame, (x1, y1 - th - 6), (x1 + tw + 4, y1), colour, -1)
            cv2.putText(frame, label, (x1 + 2, y1 - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 0), 1)

        # Overlay: unique visitor count + active tracks
        unique = len(self._globally_seen_faces)
        overlay = (f"Unique visitors: {unique}  |  "
                   f"Active tracks: {len(tracks)}  |  "
                   f"In-frame: {len(self._entry_active)}")
        cv2.rectangle(frame, (0, 0), (frame.shape[1], 40), (0, 0, 0), -1)
        cv2.putText(frame, overlay, (10, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 230, 255), 2)
        return frame

    # ── Utilities ────────────────────────────────────────────────────────

    @staticmethod
    def _generate_face_id() -> str:
        return "face_" + uuid.uuid4().hex[:12]

    def get_stats(self) -> dict:
        stats = self.db.get_stats()
        stats["session_unique_faces"] = len(self._globally_seen_faces)
        stats["currently_in_frame"] = len(self._entry_active)
        return stats

    def shutdown(self):
        self.db.close()
        self.event_logger.close()
        logger.info("Pipeline shut down cleanly.")
